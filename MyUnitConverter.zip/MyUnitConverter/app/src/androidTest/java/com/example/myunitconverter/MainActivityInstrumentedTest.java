package com.example.myunitconverter;

import android.content.Context;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.assertion.ViewAssertions;
import androidx.test.espresso.matcher.ViewMatchers;

import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;

@RunWith(AndroidJUnit4.class)
public class MainActivityInstrumentedTest {

    @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.example.myunitconverter", appContext.getPackageName());
    }

    @Test
    public void testLengthConversion() {
        // Launch MainActivity
        ActivityScenario.launch(MainActivity.class);

        // Select "Length" in the conversion type spinner
        onView(withId(R.id.spinner_conversion_type)).perform(click());
        onView(withText("Length")).perform(click());

        // Enter a value in the EditText field
        onView(withId(R.id.et_value)).perform(typeText("1"), ViewActions.closeSoftKeyboard());

        // Select "Meters" in the "from" unit spinner
        onView(withId(R.id.spinner_from_unit)).perform(click());
        onView(withText("Meters")).perform(click());

        // Select "Kilometers" in the "to" unit spinner
        onView(withId(R.id.spinner_to_unit)).perform(click());
        onView(withText("Kilometers")).perform(click());

        // Click the convert button
        onView(withId(R.id.btn_convert)).perform(click());

        // Check that the result TextView displays the correct result
        onView(withId(R.id.tv_result)).check(ViewAssertions.matches(withText("Result: 0.001")));
    }
}
