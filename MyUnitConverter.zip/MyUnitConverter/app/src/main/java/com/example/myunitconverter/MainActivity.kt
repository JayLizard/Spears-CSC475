package com.example.myunitconverter

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.*



class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // UI components
        val etValue: EditText = findViewById(R.id.et_value)
        val spinnerConversionType: Spinner = findViewById(R.id.spinner_conversion_type)
        val spinnerFromUnit: Spinner = findViewById(R.id.spinner_from_unit)
        val spinnerToUnit: Spinner = findViewById(R.id.spinner_to_unit)
        val btnConvert: Button = findViewById(R.id.btn_convert)
        val tvResult: TextView = findViewById(R.id.tv_result)

        // Data for spinners
        val conversionTypes = arrayOf("Length", "Weight", "Temperature")
        val lengthUnits = arrayOf("Meters", "Kilometers", "Miles", "Yards")
        val weightUnits = arrayOf("Kilograms", "Grams", "Pounds", "Ounces")
        val temperatureUnits = arrayOf("Celsius", "Fahrenheit", "Kelvin")

        // Set adapter for conversion type spinner
        spinnerConversionType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, conversionTypes)

        // Listener to update unit options based on the selected conversion type
        spinnerConversionType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                when (position) {
                    0 -> { // Length
                        spinnerFromUnit.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, lengthUnits)
                        spinnerToUnit.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, lengthUnits)
                    }
                    1 -> { // Weight
                        spinnerFromUnit.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, weightUnits)
                        spinnerToUnit.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, weightUnits)
                    }
                    2 -> { // Temperature
                        spinnerFromUnit.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, temperatureUnits)
                        spinnerToUnit.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, temperatureUnits)
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Button click listener to perform conversion
        btnConvert.setOnClickListener {
            val inputValue = etValue.text.toString().toDoubleOrNull()
            if (inputValue == null) {
                Toast.makeText(this, "Please enter a valid value", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val fromUnit = spinnerFromUnit.selectedItem.toString()
            val toUnit = spinnerToUnit.selectedItem.toString()
            val conversionType = spinnerConversionType.selectedItem.toString()

            val result = convertUnits(inputValue, fromUnit, toUnit, conversionType)
            tvResult.text = "Result: $result"
        }
    }

    fun convertUnits(value: Double, fromUnit: String, toUnit: String, conversionType: String): Double {
        return when (conversionType) {
            "Length" -> convertLength(value, fromUnit, toUnit)
            "Weight" -> convertWeight(value, fromUnit, toUnit)
            "Temperature" -> convertTemperature(value, fromUnit, toUnit)
            else -> value
        }
    }

    // Conversion functions
    fun convertLength(value: Double, fromUnit: String, toUnit: String): Double {
        val meters = when (fromUnit) {
            "Meters" -> value
            "Kilometers" -> value * 1000
            "Miles" -> value * 1609.34
            "Yards" -> value * 0.9144
            else -> value
        }
        return when (toUnit) {
            "Meters" -> meters
            "Kilometers" -> meters / 1000
            "Miles" -> meters / 1609.34
            "Yards" -> meters / 0.9144
            else -> meters
        }
    }

    fun convertWeight(value: Double, fromUnit: String, toUnit: String): Double {
        val kilograms = when (fromUnit) {
            "Kilograms" -> value
            "Grams" -> value / 1000
            "Pounds" -> value * 0.453592
            "Ounces" -> value * 0.0283495
            else -> value
        }
        return when (toUnit) {
            "Kilograms" -> kilograms
            "Grams" -> kilograms * 1000
            "Pounds" -> kilograms / 0.453592
            "Ounces" -> kilograms / 0.0283495
            else -> kilograms
        }
    }

    fun convertTemperature(value: Double, fromUnit: String, toUnit: String): Double {
        val celsius = when (fromUnit) {
            "Celsius" -> value
            "Fahrenheit" -> (value - 32) * 5 / 9
            "Kelvin" -> value - 273.15
            else -> value
        }
        return when (toUnit) {
            "Celsius" -> celsius
            "Fahrenheit" -> (celsius * 9 / 5) + 32
            "Kelvin" -> celsius + 273.15
            else -> celsius
        }
    }
}

