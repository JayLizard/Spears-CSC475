package com.example.myunitconverter;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MainActivityTest {

    private MainActivity mainActivity;

    @Before
    public void setUp() {
        mainActivity = new MainActivity();
    }

    // Test for length conversion
    @Test
    public void testConvertLength() {
        double result = mainActivity.convertLength(1, "Meters", "Kilometers");
        assertEquals(0.001, result, 0.0001); // Expect 1 meter to be 0.001 kilometers

        result = mainActivity.convertLength(1, "Miles", "Yards");
        assertEquals(1760, result, 0.1); // Expect 1 mile to be 1760 yards
    }

    // Test for weight conversion
    @Test
    public void testConvertWeight() {
        double result = mainActivity.convertWeight(1000, "Grams", "Kilograms");
        assertEquals(1, result, 0.0001); // Expect 1000 grams to be 1 kilogram

        result = mainActivity.convertWeight(1, "Pounds", "Kilograms");
        assertEquals(0.453592, result, 0.0001); // Expect 1 pound to be 0.453592 kilograms
    }

    // Test for temperature conversion
    @Test
    public void testConvertTemperature() {
        double result = mainActivity.convertTemperature(0, "Celsius", "Fahrenheit");
        assertEquals(32, result, 0.1); // Expect 0 Celsius to be 32 Fahrenheit

        result = mainActivity.convertTemperature(273.15, "Kelvin", "Celsius");
        assertEquals(0, result, 0.1); // Expect 273.15 Kelvin to be 0 Celsius
    }
}

