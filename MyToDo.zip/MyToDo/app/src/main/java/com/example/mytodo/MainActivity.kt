package com.example.mytodo

import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Declare variables for UI elements and Data
    private lateinit var etName: EditText
    private lateinit var etNumber: EditText
    private lateinit var btnAdd: Button
    private lateinit var btnEdit: Button
    private lateinit var btnDelete: Button
    private lateinit var lvContacts: ListView
    private lateinit var contactsAdapter: ArrayAdapter<String>
    private val contactList = mutableListOf<String>()

    // Declare and initialize SharedPreferences values
    private val PREFS_NAME = "contacts_prefs"
    private val PREFS_KEY_CONTACTS = "contacts"

    private var selectedContactIndex: Int? = null  // Declare variable to track the selected contact

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI elements via IDs
        etName = findViewById(R.id.etName)
        etNumber = findViewById(R.id.etNumber)
        btnAdd = findViewById(R.id.btnAdd)
        btnEdit = findViewById(R.id.btnEdit)
        btnDelete = findViewById(R.id.btnDelete)
        lvContacts = findViewById(R.id.lvContacts)

        // Initialize the ArrayAdapter
        contactsAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, contactList)
        lvContacts.adapter = contactsAdapter

        // Load contacts from SharedPreferences
        loadContacts()

        // Set click listeners for buttons
        btnAdd.setOnClickListener { addContact() }
        btnEdit.setOnClickListener { editContact() }
        btnDelete.setOnClickListener { deleteContact() }

        // Set click listener for ListView items
        lvContacts.setOnItemClickListener { _, _, position, _ ->
            selectedContactIndex = position  // Save the selected contact index
            val contact = contactList[position]
            val parts = contact.split(": ")
            etName.setText(parts[0])
            etNumber.setText(parts[1])
        }
    }

    // Define functions for adding, editing, and deleting contacts
    private fun addContact() {
        val name = etName.text.toString()
        val number = etNumber.text.toString()

        if (name.isNotEmpty() && number.isNotEmpty()) {
            val contact = "$name: $number"
            contactList.add(contact)
            contactsAdapter.notifyDataSetChanged()
            saveContacts()
            etName.text.clear()
            etNumber.text.clear()
            selectedContactIndex = null  // Clear the selection
        } else {
            Toast.makeText(this, "Please enter both name and number", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editContact() {
        selectedContactIndex?.let { index ->
            val name = etName.text.toString()
            val number = etNumber.text.toString()

            if (name.isNotEmpty() && number.isNotEmpty()) {
                val contact = "$name: $number"
                contactList[index] = contact
                contactsAdapter.notifyDataSetChanged()
                saveContacts()
                // Do not clear the input fields, so the user can see and modify the data if needed.
            } else {
                Toast.makeText(this, "Please enter both name and number", Toast.LENGTH_SHORT).show()
            }
        } ?: run {
            Toast.makeText(this, "Please select a contact to edit", Toast.LENGTH_SHORT).show()
        }
    }



    private fun deleteContact() {
        selectedContactIndex?.let { index ->
            contactList.removeAt(index)
            contactsAdapter.notifyDataSetChanged()
            saveContacts()
            etName.text.clear()
            etNumber.text.clear()
            selectedContactIndex = null  // Clear the selection
        } ?: run {
            Toast.makeText(this, "Please select a contact to delete", Toast.LENGTH_SHORT).show()
        }
    }

    // Define a function to save contacts to SharedPreferences
    private fun saveContacts() {
        val sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putStringSet(PREFS_KEY_CONTACTS, contactList.toSet())
        editor.apply()
    }

    // Define a function to load contacts from SharedPreferences
    private fun loadContacts() {
        val sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val contactsSet = sharedPreferences.getStringSet(PREFS_KEY_CONTACTS, setOf())

        contactList.clear()
        contactList.addAll(contactsSet ?: emptySet())
        contactsAdapter.notifyDataSetChanged()
    }
}
